# Supabase setup

Courant already points at the free project `courant` in the connected Supabase organization. Its schema and health-check view have been created. The client config contains only the publishable key, which is designed to be public; security relies on RLS. Do not paste privileged credentials into the client.

To set up a separate project:
1. Sign in to https://supabase.com/dashboard. Choose your organization and click **New project**. Enter a name, a strong database password, and a region near your users. Choose the free plan if offered. Create the project and wait until it is ready.
2. Select **SQL Editor → New query**. Paste the entire contents of `supabase/schema.sql`, click **Run**, and check for success. This script is for a fresh project; don't run it twice.
3. Go to **Project Settings → API Keys** and copy the publishable key. Go to **Project Settings → Data API** (or the project's Connect dialog) and copy the project URL. Put only these public values in `js/config.js`.
4. In **Authentication → Sign In / Providers → Email**, enable email/password. Under **URL Configuration**, set the Site URL to your deployed app origin and add the deployed URL to the redirect allow list. Enable email confirmation for real use; users need to confirm before signing in. Provider labels can change in the Supabase dashboard.
5. Open the app, select **Cloud account**, create an account, confirm its email if requested, sign in and create a household. Copy the private invite code shown in Settings. A second account can sign in and join with that code.
6. Verify that another account cannot read or modify data from a household it has not joined. Never publish screenshots containing a real invite code or household data.

The UI deliberately begins in local demo until an authenticated user has a household. Local and cloud data are separate; it does not sync or merge them. On a network/session failure the app changes to local demo and leaves cloud data intact. Data entered after that stays local; manually export it before clearing your browser. The project cannot reliably recover a request whose outcome is uncertain during a network failure; check the cloud before retrying. A free project may pause. Health checks can fail and do not guarantee uptime.

**Deletion:** deleting an account removes its authored records and membership; deleting an owner's account cascades to that owner's household and all its shared records. Warn roommates first. This is permanent. The app does not provide a self-service way to rotate an invite code or remove other members: restrict code sharing.

The created project's default Auth site URL is still `http://localhost:3000`. Replace it with the final deployed origin before emailing confirmation links. Supabase's default SMTP service only sends to pre-authorized project-team addresses and is rate-limited. To onboard arbitrary users with confirmations enabled, configure custom SMTP in **Authentication → Settings → SMTP Settings**. See https://supabase.com/docs/guides/auth/auth-smtp. Until those settings and delivery are verified, use local demo for judges.

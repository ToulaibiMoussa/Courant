// The publishable key is public by design; safety comes from Postgres RLS.
window.COURANT_CONFIG = { url: 'https://jjzrupwlzsybmgalbwwo.supabase.co', key: 'sb_publishable_Qsc2bX2yN1LhZa0kK9oNCg_2yWdslUB' };

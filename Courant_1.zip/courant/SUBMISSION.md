# Devpost submission draft

**Name:** Courant  
**Track:** Healthcare & Environmental  
**Tagline:** Know your balance. Share the cost. Keep the lights on.

## Inspiration
For a student flatshare or a household using prepaid electricity, an unexpected empty meter is more than an inconvenience. Small, frequent top-ups can make it hard to understand how quickly credit is disappearing or who has contributed. We designed Courant around the everyday questions: How much is left? When should we recharge? What can we change?

## What it does
Courant turns manual meter readings and recharge receipts into a shared picture of a household's electricity. It estimates days remaining from recent readings, displays top-ups and energy trends, models appliance use, and offers practical energy-saving ideas. An equal-share calculator suggests who should settle with whom. A local demo works even when the cloud is unavailable.

## How we built it
We used HTML, CSS and vanilla JavaScript without a build step. A single storage module supports localStorage and Supabase Postgres with Auth and row-level security. Charts are inline SVG. Cloud recharge searches are filtered and paginated at the server. The simulator and recommendations use illustrative values, not device measurements. We used AI assistance during development; disclose all tools your team used as required by the rules.

## Challenges and lessons
A prepaid meter is not a smart meter. Courant cannot know live consumption, so its predictions rely on readings and top-up dates. We chose to make uncertainty visible rather than present estimates as facts. Designing cloud and local modes also means not implying that unsynced local changes are already shared.

## What's next
Validate assumptions with Senegalese households and prepaid-meter users, support French and Wolof, add stronger invite management and consent, model tiered tariffs, and design explicit offline synchronization after privacy and security review.

## Built with
HTML, CSS, JavaScript, Supabase Postgres, Supabase Auth, Supabase JS, SVG, browser localStorage, AI assistance.

## Demo video outline (under three minutes)
- 0:00–0:20: Explain a household's prepaid top-up uncertainty and the Healthcare & Environmental angle.
- 0:20–0:40: Load sample data; point out local demo and the illustrative nature of the forecast.
- 0:40–1:05: Add a reading and a recharge; show the activity log and unit cost.
- 1:05–1:35: Search for a fan, change its daily hours, and compare the one-hour-less estimate.
- 1:35–1:55: Mark a saving tip and show the flatshare settlement suggestions.
- 1:55–2:20: Explain cloud membership and RLS, the local fallback, and that estimates are not live readings.
- 2:20–2:30: Close with the impact and invite judges to try the demo.

Before submission, host a working demo video on YouTube or Vimeo with embedding enabled, make your code public, add every team member on Devpost, and verify the submission. Do not claim validation, quantified environmental impact, or user adoption without evidence. Eligible team members must be students aged 13+, and the project must be new and built during the hackathon. Deadline: December 26, 2026, 12:00 AM Eastern (the start of December 26).

## Updated demonstration asset
The redesigned app's 85-second French narrated demonstration is available at `video/courant-demonstration-fr.mp4`; the optional French subtitle file is `video/sous-titres-fr.srt`. The voice is synthesized, the walkthrough uses fictitious data, and the English app interface is shown as it actually works. Upload the video to YouTube or Vimeo with embedding enabled before submission. The video itself is not a hosted submission link.

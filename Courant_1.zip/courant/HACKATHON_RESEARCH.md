# GenHacks research — checked 7 November 2026

Sources: [Overview](https://genhacks-open.devpost.com/), [Rules](https://genhacks-open.devpost.com/rules), [Resources](https://genhacks-open.devpost.com/resources), [Updates](https://genhacks-open.devpost.com/updates), [Project gallery](https://genhacks-open.devpost.com/project-gallery).

- GenHacks is online and student-only; entrants must be at least 13, with standard territorial exclusions. One team per person and one project per team. Projects must be new, started after the hackathon began; disclose open-source libraries, APIs, templates, and AI tools.
- Submissions close **December 26, 2026 at 12:00 AM Eastern** — the beginning of December 26, or 05:00 UTC that day. Check the live site before submitting. All team members must be added.
- Choose Healthcare & Environmental for the household wellbeing and energy-awareness angle. The other tracks are Robotics & IoT; AI, Agentic Systems, Cybersecurity, and Dev Tools; and Open.
- The submission requires a project page, tools and build description, a public code link, and a demonstration up to three minutes on YouTube or Vimeo with embedding enabled. Record or enhance the included silent screencast with the outline in SUBMISSION.md, upload it, and supply the link.
- Judges consider impact, technical execution, creativity and presentation. Courant focuses on the prepaid and shared-household workflow; measured social or environmental outcomes have not yet been established. The offline sample and short, transparent demo support presentation and technical execution.
- The gallery page said the organizers had **not published the gallery**. Therefore no credible competitive comparison or claim of uniqueness can be made yet.
- The Resources page suggests OBS for recording and links to GitHub guides. The Updates page advertised a Momen workshop and credit, but using it is optional; this build does not depend on it.

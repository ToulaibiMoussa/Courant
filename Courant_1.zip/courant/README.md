# Courant

A lightweight, static prepaid electricity tracker for households and flatshares. No framework or build step. Open `index.html` directly or serve the folder with `python3 -m http.server 8000`. Internet is required for cloud mode; the sample data works without a backend. If the CDN is unreachable, the app still starts in local demo. The local browser may restrict localStorage for file URLs; use a static server if so.

## Try it in 30 seconds
1. Open Courant and select **Load sample data**; accept the confirmation.
2. Observe the sample meter balance and estimated days left. Add a meter reading.
3. In Activity, add a recharge; its unit cost is calculated from the inputs.
4. Search Appliances and move a slider. Check a tip. Visit Flatshare split.
5. Export CSV in Settings. Cloud data is separate from local demo.

## Cloud
See [SETUP_SUPABASE.md](SETUP_SUPABASE.md). The included public config points to the separate Courant Supabase project. The version-pinned Supabase JS CDN library is 2.117.3. The official JS reference documents CDN support: https://supabase.com/docs/reference/javascript/installing. Project RLS, not UI button hiding, protects data. Owner-only household edits prevent ownership changes. Invite codes grant membership and must be treated as private.

To ping the one-row health view, run a weekly request like:

```sh
curl 'https://jjzrupwlzsybmgalbwwo.supabase.co/rest/v1/health_check?select=*' -H 'apikey: sb_publishable_Qsc2bX2yN1LhZa0kK9oNCg_2yWdslUB'
```

A periodic request may help prevent free-project inactivity, but Supabase can change its policies and this is not a guarantee that a project won't pause. Do not use it to circumvent a provider's terms. The local demo is the reliable fallback.

## Estimates and limitations
- The default rate of 125 FCFA/kWh is illustrative, not an official Senegal tariff. Electricity tariffs can be tiered and include taxes/fees. Edit it from your receipt.
- Balance is the latest manually entered reading; Courant cannot read a meter and does not subtract energy in real time. Daily use is estimated between consecutive readings, adding top-ups dated after the first reading and up to the second reading. Recharges are dated but not timestamped by meter event; readings and recharges on the same date may distort estimates. The forecast date is anchored to the last reading, so old readings are not treated as if they were entered today. With insufficient or inconsistent readings, no forecast is shown. The date is not a promise of service.
- Chart daily usage is interpolated across readings; unobserved days are not observed consumption. Appliance wattage and tip savings are illustrative and may overlap; neither is measured.
- Split assumes everyone listed owes an equal share of all recorded purchases. Use matching names; there is no proration for move-in dates or differing shares. Settlements are bookkeeping only, not transfers.
- Cloud recharge search is on payer and note and is applied before server-side paging; local search matches row contents. Search on appliances/tips is local. Updates are not realtime; navigate or reload to refresh. Local and cloud data are separate; no background sync, offline queue, or automatic conflict resolution. Switching to local never overwrites cloud, but a failed in-flight cloud write can have an uncertain outcome.
- Local persistence can be blocked or cleared by the browser; export CSV. CSV contains transaction records, not a complete backup of household setup or tip progress. There is no CSV import.
- Deletion of an owner's account also deletes their shared households and all members' household records. Account signup, email confirmation and deliverability depend on project auth settings. Supabase free project availability is not guaranteed.
- RLS and SQL constraints are implemented, but this prototype has not undergone an independent security audit. Invite codes do not expire or rotate in the UI. Do not use real private household data in a public demo.

## Static deployment
Upload `index.html`, `style.css`, and `js/` to any static host. Set the publish directory to the project root, with no build command. The screenshot and documentation folders are optional for deployment. Do not commit private credentials.

## Files
`js/store.js` is the single persistence boundary. `js/data.js` contains the appliance and tip catalogue. `supabase/schema.sql` recreates the database on a fresh Supabase project. `SUBMISSION.md` contains draft submission copy and a demo script.

## Verification performed
On 2026-11-07, browser tests exercised the local sample, a new reading, navigation, simulator search and slider, and screenshots. Separate tests exercised cloud sign-in, household creation, reading insertion, and account deletion; two disposable test accounts were used to verify isolation, membership joining, denied outsider insertion, a numeric check, server-side count/range, and owner-only deletion. The test accounts were deleted. Email confirmation delivery and a publicly hosted deployment have not been verified. Configure the deployed Auth site URL and SMTP as described in setup before relying on public signups.

## Deliverables
`screenshots/` contains seven genuine automated-browser screenshots using sample data. `demo-screencast.webm` is a short, silent automated walkthrough of the working local app; it is not hosted or narrated. The submission still requires the team's public code link, YouTube/Vimeo hosting with embedding enabled, team member details, and actual Devpost submission.

## Design refresh and narrated demonstration
The updated interface adds self-contained SVG navigation icons, a clearer meter card that no longer implies an arbitrary full-meter capacity, improved contrast, reduced-motion support and a labeled bottom navigation on small screens. The app remains framework-free and requires no build step; the static runtime files are under 62 KB excluding the pinned Supabase library. Local and cloud storage behavior is unchanged.

`video/courant-demonstration-fr.mp4` is an actual browser walkthrough with synthetic French narration and fictitious sample data; `video/SCRIPT_DEMONSTRATION.md` contains its transcript. It is not yet hosted on YouTube or Vimeo. The app's interface remains in English. Screenshots of the redesigned desktop and mobile layouts are in `screenshots/desktop-redesign.png` and `screenshots/mobile-redesign.png`.
